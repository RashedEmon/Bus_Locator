
import 'package:flutter/material.dart';
//import 'package:location/location.dart';
import 'package:background_location/background_location.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;
import 'package:permission_handler/permission_handler.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const MyHomePage(title: 'Locator Device'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({Key? key, required this.title}) : super(key: key);


  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  //instance variable
  bool isStart=true;
  bool locationMandatoryDialogue=false;


  Future<bool> locationPermission() async{
    print('enter in locate');
    await Permission.locationAlways.request();
     if(! await Permission.locationAlways.serviceStatus.isEnabled){
       print('enter in check');
      PermissionStatus status= await Permission.location.request();
        if(status.isDenied){
          print('enter in denied');
          return false;
        }

     }
    return true;
  }
  Future<bool> locationAndSocket() async{
    if(! await locationPermission()){
      return false;
    }
    await BackgroundLocation.setAndroidNotification(
      title: 'Background service is running',
      message: 'Background location in progress',
    );

    dynamic locationOkay= await BackgroundLocation.startLocationService(distanceFilter: 0.0000001);
    print(locationOkay);
    // while(!locationOkay){
    //   locationOkay=await locationPermission();
    //
    // }
  BackgroundLocation.getLocationUpdates((location) => {
    print(location.latitude),
    print(location.longitude),
    print(location.bearing),
  });


   return true;
  }

  @override
  void dispose(){

    BackgroundLocation.stopLocationService();

  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      appBar: AppBar(
        // Here we take the value from the MyHomePage object that was created by
        // the App.build method, and use it to set our appbar title.
        title: Center(
          child: Text(widget.title),
        ),
      ),
      body: Center(
        // Center is a layout widget. It takes a single child and positions it
        // in the middle of the parent.
        child: Row(

          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
           ElevatedButton(
              onPressed: isStart?() async {
                // channel.sink.add('hello');
                // print('ok');
               bool isEnabled= await locationAndSocket();
                if(isEnabled){
                  setState(() {
                    isStart=! isStart;
                  });
                }
              }: null,
              child: const Text(
                'Start'
              ),

            ),
            const SizedBox(width: 20,),
            ElevatedButton(
              onPressed: !isStart?(){
                dispose();
                setState(() {
                  isStart=!isStart;
                });
              }: null,
              child: const Text(
                  'Stop'
              ),

            ),
            const SizedBox(height: 50,),

          ],
        ),

      ),
       // This trailing comma makes auto-formatting nicer for build methods.
    );
  }
}


