package me.rashedul.busLocator.bus_locator

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
